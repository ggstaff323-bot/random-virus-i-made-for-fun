import win32gui, win32api, win32con, win32ui
import time, random, pyaudio, threading, ctypes, math

current_idx = 0

def warnings():
    u32 = ctypes.windll.user32
    w1 = u32.MessageBoxW(0, "Windows 12 Insider Preview has detected a display driver conflict. Would you like to optimize?", "Microsoft Windows Update", 0x30 | 0x1)
    if w1 != 1: exit()
    w2 = u32.MessageBoxW(0, "CRITICAL: Optimization will bypass GDI safety limits and increase audio gain. Continue?", "System Warning", 0x10 | 0x1)
    if w2 != 1: exit()
    w3 = u32.MessageBoxW(0, "FINAL WARNING: This process is irreversible until completion. Start?", "Windows 12 Deployment", 0x40 | 0x1)
    if w3 != 1: exit()

def play_ultra_loud_bytebeat():
    p = pyaudio.PyAudio()
    try:
        stream = p.open(format=pyaudio.paInt8, channels=1, rate=16000, output=True, frames_per_buffer=512)
    except:
        return

    t = 0
    while True:
        beats = [
            (t*(t>>5|t>>8))>>(t>>16) | (t*3),
            (t*((t>>12|t>>8)&63&t>>4)) ^ (t>>2),
            (t>>7|t|t>>6)*10+(t&t>>13|t>>6) | (t<<1),
            (t*(t>>11&t>>7))^(t>>3) | (t>>5),
            (t>>6|t|t>>(t>>16))*10+((t>>11)&7) | (t*t>>10),
            (t^t>>8)* (t>>12|t>>8) + (t>>4 & t),
            t*(t>>8&(t>>4|t>>5))&(t>>7|t>>10) | (t*7),
            (t|(t>>9|t>>7))*t&(t>>11|t>>9) ^ (t>>2),
            (t*t>>12)&(t>>4)|(t>>8) | (t*2 & t>>5),
            (t>>5|t<<1)&200|(t>>7|t<<1)&150 | (t^t>>7)
        ]
        
        try:
            f = beats[current_idx % 10]
            sample = bytes([int(f) & 0xFF])
            stream.write(sample)
            t += 1
        except:
            continue

def run_win12_gdi():
    global current_idx
    hdc = win32gui.GetDC(0)
    sw, sh = win32api.GetSystemMetrics(0), win32api.GetSystemMetrics(1)
    
    for i in range(10):
        current_idx = i
        start = time.time()
        while time.time() - start < 15:
            
            if i == 0:
                x = random.randint(0, sw)
                win32gui.BitBlt(hdc, x, random.randint(1, 30), random.randint(100, 300), sh, hdc, x, 0, win32con.SRCCOPY)
            
            elif i == 1:
                pts = [(random.randint(-100, 100), 0), (sw - random.randint(0, 100), random.randint(0, 100)), (0, sh)]
                win32gui.PlgBlt(hdc, pts, hdc, 0, 0, sw, sh, 0, 0, 0)
            
            elif i == 2:
                win32gui.BitBlt(hdc, 0, 0, sw, sh, hdc, 5, 5, win32con.SRCPAINT)
                win32gui.BitBlt(hdc, 0, 0, sw, sh, hdc, -5, -5, win32con.SRCAND)
            
            elif i == 3:
                y = random.randint(0, sh)
                win32gui.BitBlt(hdc, random.randint(-200, 200), y, sw, 20, hdc, 0, y, win32con.SRCCOPY)
            
            elif i == 4:
                win32gui.StretchBlt(hdc, 15, 15, sw - 30, sh - 30, hdc, 0, 0, sw, sh, win32con.SRCCOPY)
            
            elif i == 5:
                win32gui.BitBlt(hdc, 0, 0, sw, sh, hdc, 0, 0, win32con.NOTSRCCOPY)
                time.sleep(0.01)

            elif i == 6:
                for j in range(0, sw, 10):
                    off = int(math.sin(j/10.0 + time.time()*30)*80)
                    win32gui.BitBlt(hdc, j, off, 10, sh, hdc, j, 0, win32con.SRCCOPY)

            elif i == 7:
                win32gui.BitBlt(hdc, random.randint(-40, 40), random.randint(-40, 40), sw, sh, hdc, 0, 0, win32con.SRCINVERT)

            elif i == 8:
                win32gui.StretchBlt(hdc, sw, 0, -sw, sh, hdc, 0, 0, sw, sh, win32con.SRCCOPY)

            elif i == 9:
                win32gui.BitBlt(hdc, random.randint(-sw, sw), random.randint(-sh, sh), sw, sh, hdc, 0, 0, win32con.SRCCOPY)
                if random.random() > 0.5: 
                    win32gui.PatBlt(hdc, 0, 0, sw, sh, win32con.PATINVERT)

    win32gui.InvalidateRect(0, None, True)
    win32gui.ReleaseDC(0, hdc)

if __name__ == "__main__":
    warnings()
    threading.Thread(target=play_ultra_loud_bytebeat, daemon=True).start()
    run_win12_gdi()
